

(function (angular) {
     angular.module("calApp", [])
     .factory('MathService', function() {
        var factory = {};
        factory.multiply = function(a, b) {
            return a * b
        }
        return factory;
    });
})(angular)



//<my-calendar-range></my-calendar-range>
//<div my-calendar-range></div>
    /* recommended */
angular
    .module('app.widgets')
    .directive('myCalendarRange', myCalendarRange);

function myCalendarRange () {
    var directive = {
        link: link,
        templateUrl: '/template/is/located/here.html',
        restrict: 'EA'
    };
    return directive;

    function link(scope, element, attrs) {
        /* */
    }
}