
/**
 * Created by Administrator on 2016/9/12.
 */
var app = angular.module("myApp",[]);
// 方法1：用传统的js中的setInterval方法
// app.controller("timeController",["$scope",function ($scope) {
//     $scope.clock = {
//         now: new Date()
//     };
//     var updateClock = function() {
//         $scope.clock.now = new Date()
//     };
//     setInterval(function() {
//         $scope.$apply(updateClock);
//     }, 1000);
//     updateClock();
// }]);
// 方法2：使用angular中的定时器，但需要注入参数$interval
app.controller("timeController",["$scope","$interval",function ($scope,$interval) {
    $scope.clock = {
        now: new Date()
    };
    var updateClock = function() {
        $scope.clock.now = new Date()
    };
    $interval(function() {
      updateClock();
    }, 1000);
    updateClock();//刚开始就运行一次来获取当前时间
}]);


